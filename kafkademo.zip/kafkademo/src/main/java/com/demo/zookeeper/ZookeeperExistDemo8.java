package com.demo.zookeeper;

import org.apache.zookeeper.*;
import org.apache.zookeeper.data.Stat;

import java.util.concurrent.CountDownLatch;

public class ZookeeperExistDemo8 implements Watcher {
    private static CountDownLatch countDownLatch = new CountDownLatch(1);
    public static final String ZK_HOST = "127.0.0.1:2181";

    private static ZooKeeper zooKeeper;
    public static void main(String... args) throws Exception {
        String path = "/zk-data-set";
        zooKeeper = new ZooKeeper(ZK_HOST, 5000, new ZookeeperExistDemo8());
        countDownLatch.await();
        //检查是否存在并注册watcher
        Stat stat = zooKeeper.exists(path, true);
        if (null == stat) {
            zooKeeper.create(path, "".getBytes(), ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
            stat = new Stat();
        }
        stat = zooKeeper.setData(path, "123".getBytes(), stat.getVersion());
        //检查是否存在并注册watcher
        zooKeeper.exists(path + "/c1", true);
        zooKeeper.create(path + "/c1", "".getBytes(), ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
        zooKeeper.delete(path + "/c1", -1);
        zooKeeper.delete(path, -1);
        Thread.sleep(10000);
    }
    @Override
    public void process(WatchedEvent event) {
        if (event.getState() == Event.KeeperState.SyncConnected) {
            if (null == event.getPath() && event.getType() == Event.EventType.None) {
                countDownLatch.countDown();
            } else if (event.getType() == Event.EventType.NodeDataChanged) {
                System.out.println("node data change path = " + event.getPath());
                try {
                    zooKeeper.exists(event.getPath(), true);
                } catch (KeeperException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            } else if (event.getType() == Event.EventType.NodeCreated) {
                System.out.println("node data create " + event.getPath());
                try {
                    zooKeeper.exists(event.getPath(), true);
                } catch (KeeperException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            } else if (event.getType() == Event.EventType.NodeDeleted) {
                System.out.println("node data delete " + event.getPath());
                try {
                    zooKeeper.exists(event.getPath(), true);
                } catch (KeeperException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            } else if (event.getType() == Event.EventType.NodeChildrenChanged) {
                System.out.println("node children change " + event.getPath());
                try {
                    zooKeeper.exists(event.getPath(), true);
                } catch (KeeperException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
