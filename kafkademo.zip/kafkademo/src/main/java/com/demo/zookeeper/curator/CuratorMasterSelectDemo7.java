package com.demo.zookeeper.curator;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.framework.recipes.leader.LeaderSelector;
import org.apache.curator.framework.recipes.leader.LeaderSelectorListener;
import org.apache.curator.framework.recipes.leader.LeaderSelectorListenerAdapter;
import org.apache.curator.retry.ExponentialBackoffRetry;

import java.util.List;

public class CuratorMasterSelectDemo7 {
    public static final String ZK_HOST = "127.0.0.1:2181";

    public static void main(String... args) throws InterruptedException {
        CuratorFramework curatorFramework = CuratorFrameworkFactory.builder()
                .connectString(ZK_HOST)
                .connectionTimeoutMs(1000)
                .sessionTimeoutMs(5000)
                .retryPolicy(new ExponentialBackoffRetry(1000, 3))
                .build();
        curatorFramework.start();
        String path = "/curator_master_path";
        LeaderSelector selector = new LeaderSelector(curatorFramework, path, new LeaderSelectorListenerAdapter() {
            @Override
            public void takeLeadership(CuratorFramework client) throws Exception {
                System.out.println("成为master");
                Thread.sleep(3000);
                List<String> strings = client.getChildren().forPath(path);
                System.out.println("子节点：" + strings);
                System.out.println("完成master操作");
            }
        });
        selector.autoRequeue();
        selector.start();
        Thread.sleep(Integer.MAX_VALUE);
    }
}
