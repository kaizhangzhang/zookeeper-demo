package com.demo.zookeeper;

import org.apache.zookeeper.*;

import java.io.IOException;
import java.util.concurrent.CountDownLatch;

public class ZookeeperCreateNodeDemo3 implements Watcher {
    private static CountDownLatch countDownLatch = new CountDownLatch(1);
    public static final String ZK_HOST = "127.0.0.1:2181";

    public static void main(String... args) {
        try {
            ZooKeeper zooKeeper = new ZooKeeper(ZK_HOST, 5000, new ZookeeperCreateNodeDemo3());
            countDownLatch.await();
            //临时节点
            String path = zooKeeper.create("/zk-test-ephemeral-", "".getBytes(), ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL);
            System.out.println("success create path znode = " + path);

            //顺序节点
            String path2 = zooKeeper.create("/zk-test-ephemeral-", "".getBytes(), ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL_SEQUENTIAL);
            System.out.println("success create payh " + path2);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    @Override
    public void process(WatchedEvent event) {
        if (event.getState() == Event.KeeperState.SyncConnected) {
            countDownLatch.countDown();
        }
    }
}
