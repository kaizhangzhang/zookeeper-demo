package com.demo.zookeeper.curator;

import org.apache.curator.RetryPolicy;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.ExponentialBackoffRetry;

public class CuratorCreateDemo1 {
    public static final String ZK_HOST = "127.0.0.1:2181";
    public static void main(String... args) {
        RetryPolicy retryPolicy = new ExponentialBackoffRetry(1000, 3);
        CuratorFramework frameworkFactory = CuratorFrameworkFactory.newClient(ZK_HOST,
                5000, 1000, retryPolicy);
        frameworkFactory.start();
    }
}
