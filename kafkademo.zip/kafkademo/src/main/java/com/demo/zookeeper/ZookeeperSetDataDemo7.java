package com.demo.zookeeper;

import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.data.Stat;

import java.util.concurrent.CountDownLatch;

public class ZookeeperSetDataDemo7 implements Watcher {
    public static final String ZK_HOST = "127.0.0.1:2181";
    private static ZooKeeper zooKeeper;
    private static CountDownLatch countDownLatch = new CountDownLatch(1);
    private static Stat stat = new Stat();

    public static void main(String... args) throws Exception {
        String path = "/zk-data";
        zooKeeper = new ZooKeeper(ZK_HOST, 5000, new ZookeeperSetDataDemo7());
        countDownLatch.await();
        zooKeeper.getData(path, true, stat);
        stat = zooKeeper.setData(path, "456".getBytes(), stat.getVersion());
        stat = zooKeeper.setData(path, "567".getBytes(), stat.getVersion());
        byte[] data = zooKeeper.getData(path, true, stat);
        System.out.println(new String(data));
    }

    @Override
    public void process(WatchedEvent event) {
        if (event.getState() == Event.KeeperState.SyncConnected) {
            if (event.getType() == Event.EventType.None && null == event.getPath()) {
                countDownLatch.countDown();
            } else if (event.getType() == Event.EventType.NodeDataChanged) {
                try {
                    byte[] data = zooKeeper.getData(event.getPath(), true, null);
                    System.out.println(new String(data));
                } catch (KeeperException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
