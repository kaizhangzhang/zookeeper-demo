package com.demo.zookeeper.curator;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.framework.recipes.cache.PathChildrenCache;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheEvent;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheListener;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.data.Stat;

public class CuratorPathChildrenCacheDemo6 {
    public static final String ZK_HOST = "127.0.0.1:2181";

    public static void main(String... args) throws Exception {
        CuratorFramework framework = CuratorFrameworkFactory.builder()
                .connectString(ZK_HOST)
                .connectionTimeoutMs(1000)
                .sessionTimeoutMs(5000)
                .retryPolicy(new ExponentialBackoffRetry(1000, 3))
                .build();
        framework.start();
        String path = "/zk-book";

        PathChildrenCache pathChildrenCache = new PathChildrenCache(framework, path, true);
        pathChildrenCache.start(PathChildrenCache.StartMode.POST_INITIALIZED_EVENT);
        pathChildrenCache.getListenable().addListener(new PathChildrenCacheListener() {
            @Override
            public void childEvent(CuratorFramework client, PathChildrenCacheEvent event) throws Exception {
                switch (event.getType()) {
                    case CHILD_ADDED:
                        System.out.println("children add path = " + event.getData().getPath());
                        break;
                    case CHILD_UPDATED:
                        System.out.println("children update path = " + event.getData().getPath());

                        break;
                    case CHILD_REMOVED:
                        System.out.println("children remove path = " + event.getData().getPath());

                        break;
                        default: break;
                }
            }
        });
        framework.create().creatingParentsIfNeeded().withMode(CreateMode.PERSISTENT).forPath(path + "/c1");
        Thread.sleep(1000);
        framework.delete().forPath(path + "/c1");
        Thread.sleep(1000);
        framework.delete().forPath(path);
        Thread.sleep(1000);
    }
}
