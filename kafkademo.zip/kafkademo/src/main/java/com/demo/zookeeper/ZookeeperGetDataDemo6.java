package com.demo.zookeeper;

import org.apache.zookeeper.*;
import org.apache.zookeeper.data.Stat;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CountDownLatch;

public class ZookeeperGetDataDemo6 implements Watcher {
    public static final String ZK_HOST = "127.0.0.1:2181";
    private static CountDownLatch countDownLatch = new CountDownLatch(1);
    private static ZooKeeper zooKeeper;
    private static Stat stat = new Stat();
    public static void main(String... args) throws Exception {
        String path = "/zk-data";
        zooKeeper = new ZooKeeper(ZK_HOST, 5000, new ZookeeperGetDataDemo6());
        countDownLatch.await();
        byte[] data = zooKeeper.getData(path, true, stat);
        System.out.println(stat.getCzxid() + "," + stat.getMzxid()+ "," + stat.getVersion());

        //异步获取data
        zooKeeper.getData(path, true, new AsyncCallback.DataCallback() {
            @Override
            public void processResult(int rc, String path, Object ctx, byte[] data, Stat stat) {
                System.out.println("result code = " + rc + "， path = " + path + ", data = " + new String(data));
                System.out.println(stat.getCzxid() + "," + stat.getMzxid()+ "," + stat.getVersion());
            }
        }, null);

        zooKeeper.setData(path, "123".getBytes(), -1);

        Thread.sleep(10000);
    }

    @Override
    public void process(WatchedEvent event) {
        if (event.getState() == Event.KeeperState.SyncConnected) {
            if (event.getType() == Event.EventType.None && null == event.getPath()) {
                countDownLatch.countDown();
            } else if (event.getType() == Event.EventType.NodeDataChanged) {
                try {
                    System.out.println(new String(zooKeeper.getData(event.getPath(), true, stat)));
                } catch (KeeperException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println(stat.getCzxid() + "," + stat.getMzxid()+ "," + stat.getVersion());
            }

        }
    }
}

