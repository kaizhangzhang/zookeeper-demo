package com.demo.zookeeper.curator;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.data.Stat;

public class CuratorCrudNodeDemo3 {
    public static final String ZK_HOST = "127.0.0.1:2181";

    public static void main(String... args) throws Exception {
        String path = "/zk-book-c/c1";
        CuratorFramework build = CuratorFrameworkFactory.builder()
                .connectString(ZK_HOST)
                .connectionTimeoutMs(1000)
                .sessionTimeoutMs(5000)
                .retryPolicy(new ExponentialBackoffRetry(1000, 3))
                .build();
        build.start();
        //新建节点
        String forPath = build.create()
                .creatingParentsIfNeeded()
                .withMode(CreateMode.EPHEMERAL)
                .forPath(path, "init".getBytes());
        System.out.println("success create node path = " + forPath);
        //读取
        Stat stat = new Stat();
        byte[] bytes = build.getData().storingStatIn(stat).forPath(path);
        System.out.println("read data = " + new String(bytes) + " ,version = " + stat.getVersion());

        //更新
        build.setData().withVersion(stat.getVersion()).forPath(path, "123".getBytes());
        byte[] bytes1 = build.getData().storingStatIn(stat).forPath(path);
        System.out.println("update data = " + new String(bytes1) + " ,version = " + stat.getVersion());

        //删除
        build.delete()
                .guaranteed()//保障一定能删除成功 即使网络抖动了
                .deletingChildrenIfNeeded()
                .withVersion(stat.getVersion())
                .forPath(path);
    }
}
