package com.demo.zookeeper;

import com.alibaba.fastjson.JSON;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;

import java.io.IOException;
import java.util.concurrent.CountDownLatch;

public class ZookeeperConstructDemo1 implements Watcher {
    private static CountDownLatch connectedSemaphore = new CountDownLatch(1);
    public static final String ZK_HOST = "127.0.0.1:2181";
    public static void main(String... args) {
        try {
            ZooKeeper zooKeeper = new ZooKeeper(ZK_HOST, 5000, new ZookeeperConstructDemo1());
            System.out.println(zooKeeper.getState());
            connectedSemaphore.await();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("zookeeper session established");
        try {
            Thread.sleep(Integer.MAX_VALUE);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void process(WatchedEvent watchedEvent) {
        System.out.println("recive event = " + JSON.toJSONString(watchedEvent));
        if (watchedEvent.getState().equals(Event.KeeperState.SyncConnected)) {
            connectedSemaphore.countDown();
        }
    }
}
