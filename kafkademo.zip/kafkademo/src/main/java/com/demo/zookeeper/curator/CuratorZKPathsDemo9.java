package com.demo.zookeeper.curator;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.curator.utils.ZKPaths;

public class CuratorZKPathsDemo9 {
    public static final String ZK_HOST = "127.0.0.1:2181";

    public static void main(String... args) throws Exception {
        String path = "/curator_zk_path";

        CuratorFramework curatorFramework = CuratorFrameworkFactory.builder()
                .connectString(ZK_HOST)
                .connectionTimeoutMs(1000)
                .sessionTimeoutMs(5000)
                .retryPolicy(new ExponentialBackoffRetry(1000, 3))
                .build();
        curatorFramework.start();
        System.out.println(ZKPaths.fixForNamespace(path, "/sub"));
        System.out.println(ZKPaths.makePath(path, "/sub"));
        System.out.println(ZKPaths.getNodeFromPath(path + "/sub1"));

        ZKPaths.PathAndNode pathAndNode = ZKPaths.getPathAndNode(path + "/sub1");
        System.out.println(pathAndNode.getPath());
        System.out.println(pathAndNode.getNode());

        String dir1 = path + "/child1";
        String dir2 = path + "/child2";
        ZKPaths.mkdirs(curatorFramework.getZookeeperClient().getZooKeeper(), dir1);
        ZKPaths.mkdirs(curatorFramework.getZookeeperClient().getZooKeeper(), dir2);
        System.out.println(ZKPaths.getSortedChildren(curatorFramework.getZookeeperClient().getZooKeeper(), path));
        ZKPaths.deleteChildren(curatorFramework.getZookeeperClient().getZooKeeper(), path, true);
    }
}
