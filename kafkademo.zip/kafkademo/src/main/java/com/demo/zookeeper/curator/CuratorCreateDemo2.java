package com.demo.zookeeper.curator;

import org.apache.curator.RetryPolicy;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.ExponentialBackoffRetry;

public class CuratorCreateDemo2 {
    public static final String ZK_HOST = "127.0.0.1:2181";
    public static void main(String... args) throws InterruptedException {
        RetryPolicy retryPolicy = new ExponentialBackoffRetry(1000, 3);

        CuratorFramework build = CuratorFrameworkFactory.builder()
                .connectString(ZK_HOST)
                .sessionTimeoutMs(5000)
                .connectionTimeoutMs(1000)
                .retryPolicy(retryPolicy)
                .namespace("base")
                .build();
        build.start();
        Thread.sleep(10000);
    }
}
