package com.demo.zookeeper;

import org.apache.zookeeper.*;

import java.io.IOException;
import java.util.concurrent.CountDownLatch;

public class ZookeeperAsyncCreateNodeDemo4 implements Watcher {
    public static final String ZK_HOST = "127.0.0.1:2181";

    private static CountDownLatch countDownLatch = new CountDownLatch(1);

    public static void main(String... args) throws Exception {
        ZooKeeper zooKeeper = new ZooKeeper(ZK_HOST, 5000, new ZookeeperAsyncCreateNodeDemo4());
        countDownLatch.await();
        zooKeeper.create("/zk-test-ephemeral-", "".getBytes(),
                ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL,
                new IStringCallback(), "i am contxt");
        zooKeeper.create("/zk-test-ephemeral-", "".getBytes(),
                ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL_SEQUENTIAL,
                new IStringCallback(), "i am contxt");
        Thread.sleep(10000);
    }

    @Override
    public void process(WatchedEvent event) {
        if (event.getState() == Event.KeeperState.SyncConnected) {
            countDownLatch.countDown();
        }
    }

}
class IStringCallback implements AsyncCallback.StringCallback{

    @Override
    public void processResult(int rc, String path, Object ctx, String name) {
        if (rc == 0) {
            //成功
            System.out.println("Create path result: rc = " + rc + ", path = " + path + ", ctx = " + ctx + ", real path name = "+ name);
        }
    }
}
