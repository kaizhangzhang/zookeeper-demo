package com.demo.zookeeper;

import com.alibaba.fastjson.JSON;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;

import java.io.IOException;
import java.util.concurrent.CountDownLatch;

public class ZookeeperConstructSessionDemo2 implements Watcher {
    private static CountDownLatch connectedSemaphore = new CountDownLatch(1);
    public static final String ZK_HOST = "127.0.0.1:2181";
    public static void main(String... args) {
        try {
            ZooKeeper zooKeeper = new ZooKeeper(ZK_HOST, 5000, new ZookeeperConstructSessionDemo2());
            connectedSemaphore.await();
            long sessionId = zooKeeper.getSessionId();
            byte[] sessionPasswd = zooKeeper.getSessionPasswd();
            System.out.println(zooKeeper.getState());

            zooKeeper = new ZooKeeper(ZK_HOST, 5000,
                    new ZookeeperConstructSessionDemo2(),
                    1l, "test".getBytes());
            Thread.sleep(5000);
            System.out.println(zooKeeper.getState());

            zooKeeper = new ZooKeeper(ZK_HOST, 5000, new ZookeeperConstructSessionDemo2(),
                    sessionId, sessionPasswd);
            Thread.sleep(5000);
            System.out.println(zooKeeper.getState());

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void process(WatchedEvent event) {
        System.out.println("recive event = " + JSON.toJSONString(event));
        if (event.getState().equals(Event.KeeperState.SyncConnected)) {
            connectedSemaphore.countDown();
        }
    }
}
