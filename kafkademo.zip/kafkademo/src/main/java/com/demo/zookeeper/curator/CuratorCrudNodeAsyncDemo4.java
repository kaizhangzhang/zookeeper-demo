package com.demo.zookeeper.curator;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.framework.api.CuratorEvent;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.zookeeper.CreateMode;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CuratorCrudNodeAsyncDemo4 {
    public static final String ZK_HOST = "127.0.0.1:2181";

    public static void main(String... args) throws Exception {
        String path = "/zk-data-async";
        ExecutorService tp = Executors.newFixedThreadPool(2);
        CountDownLatch countDownLatch = new CountDownLatch(2);
        CuratorFramework curatorFramework = CuratorFrameworkFactory.builder()
                .connectString(ZK_HOST)
                .connectionTimeoutMs(1000)
                .sessionTimeoutMs(5000)
                .retryPolicy(new ExponentialBackoffRetry(1000, 3))
                .build();
        curatorFramework.start();
        System.out.println("main thread name = " + Thread.currentThread().getName());
        curatorFramework.create()
                .creatingParentsIfNeeded()
                .withMode(CreateMode.EPHEMERAL)
                .inBackground((CuratorFramework framework, CuratorEvent event) -> {
                    System.out.println("exexuror event code = " + event.getResultCode() +
                            ", type = " + event.getType());
                    System.out.println("exexuror inBackground thread name = " + Thread.currentThread().getName());
                    countDownLatch.countDown();
                }, tp)//使用线程池处理会掉
                .forPath(path, "123".getBytes());

        curatorFramework.create()
                .creatingParentsIfNeeded()
                .withMode(CreateMode.EPHEMERAL)
                .inBackground((CuratorFramework framework, CuratorEvent event) -> {
                    System.out.println("event code = " + event.getResultCode() +
                            ", type = " + event.getType());
                    System.out.println("inBackground thread name = " + Thread.currentThread().getName());
                    countDownLatch.countDown();
                })//默认的EventThread处理
                .forPath(path, "123".getBytes());

        countDownLatch.await();
        tp.shutdown();
    }
}
