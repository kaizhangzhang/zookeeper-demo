package com.demo.kafka.producer;

import com.alibaba.fastjson.JSON;
import com.demo.kafka.partition.DemoPartitioner;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.Properties;
import java.util.concurrent.Future;

public class ProducerFastStart {
    public static final String brokerList = "localhost:9092";
    public static final String topic = "topic-demo";
    public static void main(String ...args) throws Exception {
        Properties kafkaProps = new Properties();
        kafkaProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, brokerList);
        kafkaProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        kafkaProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        kafkaProps.put(ProducerConfig.PARTITIONER_CLASS_CONFIG, DemoPartitioner.class.getName());
        KafkaProducer<String, String> producer = new KafkaProducer<String, String>(kafkaProps);
        for (int  i = 0; i < 100;i ++) {
            ProducerRecord<String, String> record = new ProducerRecord<String, String>(topic, "hello kafka " + i);
            Future<RecordMetadata> metadataFuture = producer.send(record, new Callback() {
                @Override
                public void onCompletion(RecordMetadata recordMetadata, Exception e) {
                    System.out.println("callback " + recordMetadata.topic() + "-" + recordMetadata.partition() + ":" + recordMetadata.offset());
                }
            });
            RecordMetadata metadata = metadataFuture.get();
            System.out.println(metadata.topic() + "-" + metadata.partition() + ":" + metadata.offset());
        }
        producer.close();
    }
}
