package com.demo.kafka;

import java.util.concurrent.*;

public class ThreadDemo {
    public static void main(String... args) {
        ExecutorService executorService =new ThreadPoolExecutor(1, 1,
                0L, TimeUnit.MILLISECONDS,
                new ArrayBlockingQueue<>(1));
        for (int i = 0; i < 100; i ++) {

            Future<?> future = executorService.submit(() -> {
                try {
                    Thread.sleep(200);
                    Thread.sleep(200);
                    Thread.sleep(200);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println(Thread.currentThread().getId() + ", " + Thread.currentThread().getName() + ", " + Thread.currentThread().getState());
            });
            try {
                future.get(20, TimeUnit.MILLISECONDS);
                future.cancel(true);
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (TimeoutException e) {
                e.printStackTrace();
            }
        }
        try {
            Thread.sleep(5000);
            System.out.println("end");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
