package com.demo.kafka.consumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.TopicPartition;

import java.time.Duration;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

public class ConsumerFastStart {
    public static final String brokerList = "localhost:9092";
    public static final String topic = "topic-demo";
    public static final String groupId = "group-demo1";
    public static void main(String... args) {
        long lastConsumerOffset = -1;
        Properties kafkaProps = new Properties();
        kafkaProps.put("bootstrap.servers", brokerList);
        kafkaProps.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        kafkaProps.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        kafkaProps.put("group.id", groupId);
        KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(kafkaProps);
//        consumer.subscribe(Collections.singleton(topic));
        TopicPartition tp = new TopicPartition(topic, 0);//只消费0分区
        consumer.assign(Collections.singletonList(tp));
        while (true) {
            ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(1000));
            List<ConsumerRecord<String, String>> partionRecords = records.records(tp);
            if (null == partionRecords || partionRecords.size() <= 0) {
                continue;
            }
            lastConsumerOffset = partionRecords.get(partionRecords.size() - 1).offset();
            for (ConsumerRecord<String, String> record : records) {
                System.out.println("topic = " + record.topic() +
                        ", partition = " + record.partition() +
                        " , offset = " + record.offset() +
                        ", value = " + record.value());
            }
            consumer.commitSync();
            System.out.println("consumer offset = " + lastConsumerOffset);
            OffsetAndMetadata committed = consumer.committed(tp);
            System.out.println("commit offset = " + committed.offset());
        }
    }
}
