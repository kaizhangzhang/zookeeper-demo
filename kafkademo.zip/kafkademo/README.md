1. kafka demo
2. zookeeper demo